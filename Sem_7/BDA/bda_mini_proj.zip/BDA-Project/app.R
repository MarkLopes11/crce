# ==========================================
# Twitter Sentiment Dashboard (Bloom Filter + Count-Min Sketch)
# ==========================================

# Load required libraries
library(shiny)
library(ggplot2)
library(dplyr)
library(syuzhet)
library(plotly)
library(shinydashboard)
library(shinycssloaders)
library(stringr)

# -------------------------------
# Helper: list CSV files in HDFS
# -------------------------------
list_hdfs_files <- function(path = "/twitter_data") {
  files <- system(paste("hdfs dfs -ls", path), intern = TRUE)
  csv_files <- grep("\\.csv$", files, value = TRUE)
  if (length(csv_files) == 0) return(character(0))
  sapply(strsplit(csv_files, "\\s+"), tail, 1)
}

# -------------------------------
# Helper: read CSV from HDFS
# -------------------------------
read_hdfs_csv <- function(hdfs_path) {
  read.csv(pipe(paste("hdfs dfs -cat", hdfs_path)), stringsAsFactors = FALSE)
}

# -------------------------------
# Bloom Filter Implementation
# -------------------------------
bloom_init <- function(size = 10000) rep(FALSE, size)

bloom_add <- function(bloom, item) {
  hashes <- abs(sapply(1:3, function(i) { (sum(as.integer(charToRaw(item))) + i * 31) %% length(bloom) })) + 1
  bloom[hashes] <- TRUE
  bloom
}

bloom_check <- function(bloom, item) {
  hashes <- abs(sapply(1:3, function(i) { (sum(as.integer(charToRaw(item))) + i * 31) %% length(bloom) })) + 1
  all(bloom[hashes])
}

# -------------------------------
# Count-Min Sketch Implementation
# -------------------------------
cms_init <- function(width = 1000, depth = 5) {
  list(matrix(0, nrow = depth, ncol = width), width, depth)
}

cms_add <- function(cms, item) {
  mat <- cms[[1]]
  width <- cms[[2]]
  depth <- cms[[3]]
  for (i in 1:depth) {
    idx <- (sum(as.integer(charToRaw(item))) + i * 97) %% width + 1
    mat[i, idx] <- mat[i, idx] + 1
  }
  cms[[1]] <- mat
  cms
}

cms_estimate <- function(cms, item) {
  mat <- cms[[1]]
  width <- cms[[2]]
  depth <- cms[[3]]
  est <- sapply(1:depth, function(i) {
    idx <- (sum(as.integer(charToRaw(item))) + i * 97) %% width + 1
    mat[i, idx]
  })
  min(est)
}

cms_top_words <- function(cms, words, n = 10) {
  unique_words <- unique(words)
  freq_estimates <- sapply(unique_words, function(w) cms_estimate(cms, w))
  df <- data.frame(Word = unique_words, EstimatedFrequency = freq_estimates)
  df %>% arrange(desc(EstimatedFrequency)) %>% head(n)
}

# -------------------------------
# UI
# -------------------------------
ui <- dashboardPage(
  dashboardHeader(title = "Twitter Sentiment Dashboard"),
  dashboardSidebar(
    h4("Data Selection"),
    selectInput("hdfs_file", "Select CSV from HDFS:", choices = list_hdfs_files(), selected = NULL),
    actionButton("analyze", "🔍 Analyze Sentiment"),
    hr(),
    h4("Add New Tweet"),
    textAreaInput("new_tweet", "Enter Tweet:", placeholder = "Type your tweet here...", rows = 3),
    actionButton("add_tweet", "➕ Add Tweet"),
    hr(),
    p("This dashboard performs sentiment analysis, duplicate detection (Bloom Filter), and word frequency estimation (Count-Min Sketch).")
  ),
  dashboardBody(
    tabsetPanel(
      tabPanel("📊 Sentiment Plot", withSpinner(plotlyOutput("sentimentPlot", height = "500px"))),
      tabPanel("📋 Sentiment Data", withSpinner(tableOutput("sentimentTable"))),
      tabPanel("🔥 Top Tweets", withSpinner(tableOutput("topTweets"))),
      tabPanel("🧩 Duplicate Detection (Bloom Filter)", withSpinner(plotOutput("bloomPlot")), tableOutput("bloomStats")),
      tabPanel("📈 Word Frequency (Count-Min Sketch)",
               withSpinner(plotlyOutput("cmsPlot", height = "500px")),
               tableOutput("cmsTable")),
      tabPanel("➕ Add Tweet",
               fluidRow(
                 box(title = "Tweet Duplicate Check", status = "primary", solidHeader = TRUE, width = 12,
                     uiOutput("duplicateCheckUI"), hr(),
                     h4("Recently Added Tweets"), tableOutput("recentTweets"))
               ))
    )
  )
)

# -------------------------------
# Server
# -------------------------------
server <- function(input, output, session) {

  bloom_filter <- reactiveVal(bloom_init(50000))
  added_tweets <- reactiveVal(data.frame(Tweet = character(), Status = character(), Timestamp = character(), stringsAsFactors = FALSE))
  cms_data <- reactiveVal(NULL)

  # ===============================
  # Sentiment Analysis from HDFS
  # ===============================
  sentiment_data <- eventReactive(input$analyze, {
    req(input$hdfs_file)
    withProgress(message = "Analyzing tweets from HDFS...", value = 0, {
      incProgress(0.2, detail = "Reading CSV...")
      tweets_df <- read_hdfs_csv(input$hdfs_file)
      Sys.sleep(0.5)
      if (!("Text" %in% colnames(tweets_df))) {
        showNotification("Error: CSV must have a 'Text' column.", type = "error")
        return(NULL)
      }
      incProgress(0.5, detail = "Performing sentiment analysis...")
      tweet_text <- tweets_df$Text
      sentiments <- get_nrc_sentiment(tweet_text)
      sentiment_counts <- colSums(sentiments)
      df <- data.frame(sentiment = names(sentiment_counts), count = sentiment_counts)

      # Bloom Filter init
      bloom <- bloom_init(50000)
      for (t in tweet_text) {
        bloom <- bloom_add(bloom, t)
      }
      bloom_filter(bloom)

      # Count-Min Sketch
      incProgress(0.7, detail = "Estimating word frequencies...")
      cms <- cms_init()
      words <- unlist(str_split(tolower(tweet_text), "\\s+"))
      words <- gsub("[^a-z#]", "", words)
      words <- words[nchar(words) > 2]
      for (w in words) cms <- cms_add(cms, w)
      cms_data(list(cms = cms, words = words))

      incProgress(1, detail = "Done!")
      list(sentiment_df = df, tweets_df = tweets_df)
    })
  })

  # Sentiment Plot
  output$sentimentPlot <- renderPlotly({
    res <- sentiment_data()
    req(res)
    df <- res$sentiment_df
    p <- ggplot(df, aes(x = reorder(sentiment, count), y = count, fill = sentiment)) +
      geom_bar(stat = "identity") + coord_flip() +
      theme_minimal(base_size = 14) +
      labs(title = "Twitter Sentiment Distribution", x = "Sentiment", y = "Count") +
      theme(legend.position = "none")
    ggplotly(p)
  })

  # Sentiment Table
  output$sentimentTable <- renderTable({
    res <- sentiment_data()
    req(res)
    df <- res$sentiment_df
    df[order(-df$count), ]
  })

  # ===============================
  # Add New Tweet Handler
  # ===============================
  observeEvent(input$add_tweet, {
    new_tweet <- str_trim(input$new_tweet)
    if (new_tweet == "") {
      showNotification("Please enter a tweet first!", type = "error")
      return(NULL)
    }

    bloom <- bloom_filter()
    is_dup <- bloom_check(bloom, new_tweet)
    status <- ifelse(is_dup, "Duplicate", "Added")

    # Update Bloom filter if unique
    if (!is_dup) {
      bloom <- bloom_add(bloom, new_tweet)
      bloom_filter(bloom)
    }

    # Store in added_tweets
    new_entry <- data.frame(
      Tweet = new_tweet,
      Status = status,
      Timestamp = as.character(Sys.time()),
      stringsAsFactors = FALSE
    )

    added_tweets(rbind(new_entry, added_tweets()))
  })

  # Duplicate check result
  output$duplicateCheckUI <- renderUI({
    latest <- head(added_tweets(), 1)
    if (nrow(latest) == 0) return(h4("No tweets added yet."))
    color <- ifelse(latest$Status == "Duplicate", "red", "green")
    h4(HTML(paste0("<b>Last Tweet Status:</b> <span style='color:", color, "'>", latest$Status, "</span>")))
  })

  # Recently added tweets table
  output$recentTweets <- renderTable({
    head(added_tweets(), 10)
  })

  # ===============================
  # Bloom Filter Visualization
  # ===============================
  bloom_data <- reactive({
    res <- sentiment_data()
    req(res)
    tweets_df <- res$tweets_df
    unique_count <- 0
    duplicate_count <- 0
    bloom <- bloom_init(50000)
    for (t in tweets_df$Text) {
      if (!bloom_check(bloom, t)) {
        bloom <- bloom_add(bloom, t)
        unique_count <- unique_count + 1
      } else {
        duplicate_count <- duplicate_count + 1
      }
    }
    df <- data.frame(Type = c("Unique Tweets", "Duplicate Tweets"), Count = c(unique_count, duplicate_count))
    list(df = df, total = nrow(tweets_df))
  })

  output$bloomPlot <- renderPlot({
    bloom_res <- bloom_data()
    df <- bloom_res$df
    ggplot(df, aes(x = "", y = Count, fill = Type)) +
      geom_bar(stat = "identity", width = 1) +
      coord_polar("y", start = 0) +
      theme_void() +
      labs(title = "Tweet Uniqueness (Bloom Filter)") +
      scale_fill_manual(values = c("Unique Tweets" = "#4CAF50", "Duplicate Tweets" = "#F44336"))
  })

  output$bloomStats <- renderTable({
    bloom_res <- bloom_data()
    df <- bloom_res$df
    total <- bloom_res$total
    df$Percentage <- paste0(round((df$Count / total) * 100, 2), "%")
    df
  })

  # ===============================
  # Count-Min Sketch Visualization
  # ===============================
  output$cmsTable <- renderTable({
    cms_res <- cms_data()
    req(cms_res)
    top_words <- cms_top_words(cms_res$cms, cms_res$words, n = 10)
    top_words
  })

  output$cmsPlot <- renderPlotly({
    cms_res <- cms_data()
    req(cms_res)
    top_words <- cms_top_words(cms_res$cms, cms_res$words, n = 10)
    p <- ggplot(top_words, aes(x = reorder(Word, EstimatedFrequency), y = EstimatedFrequency, fill = Word)) +
      geom_bar(stat = "identity") +
      coord_flip() +
      theme_minimal(base_size = 14) +
      labs(title = "Top Frequent Words (Count-Min Sketch)", x = "Word", y = "Estimated Frequency") +
      theme(legend.position = "none")
    ggplotly(p)
  })
}

# -------------------------------
# Run the Shiny App
# -------------------------------
shinyApp(ui = ui, server = server)

